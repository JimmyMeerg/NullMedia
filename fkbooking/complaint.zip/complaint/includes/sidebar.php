<nav class="ts-sidebar">
            <ul class="ts-sidebar-menu">

                <li class="ts-label">Main</li>

				<li><a href="index.php"><i class="fa fa-dashboard"></i> Dashboard </a></li>

                    <li><a href="#"><i class="fa fa-files-o"></i> Manage Room</a>
                            <ul>
                                <li><a href="add-complaint.php">Submit A Complaint </a></li>
                                <li><a href="manage-complaint.php">Manage Complaint</a></li>
                            </ul>
                    </li>
                    <li><a href="#"><i class="fa fa-files-o"></i> Setup Requirement </a>
                            <ul>
                                <li><a href="add-complaint.php">Submit A Complaint</a></li>
                                <li><a href="manage-complaint.php">Manage Complaint</a></li>
                            </ul>
                    </li>    	
                    <li><a href="#"><i class="fa fa-files-o"></i> Booking List </a>
                            <ul>
                                <li><a href="add-complaint.php">Submit A Complaint</a></li>
                                <li><a href="manage-complaint.php">Manage Complaint</a></li>
                            </ul>
                    </li>  
                    <li><a href="#"><i class="fa fa-files-o"></i> Complaint </a>
                            <ul>
                                <li><a href="add-complaint.php">Submit A Complaint</a></li>
                                <li><a href="manage-complaint.php">Manage Complaint</a></li>
                                <li><a href="graph-complaint.php">Visualization Report</a></li>
                            </ul>
                    </li>
                
                </li>



    </ul>
        </nav>
