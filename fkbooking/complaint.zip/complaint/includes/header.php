<div class="brand clearfix">
        <a href="#" class="logo" style="font-size:16px;">FK BOOKING SYSTEM</a>
        <span class="menu-btn"><i class="fa fa-bars"></i></span>
       
    </div>

